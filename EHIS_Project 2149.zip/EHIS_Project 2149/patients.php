<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Database connection
$servername = "localhost";
$username = "root";
$password = " "; 
$dbname = "patientsdb"; //put the databse you created

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];
$dob = $_POST['dob'];
$account = $_POST['account'];
$password = $_POST['password'];
$confirm_password = $_POST['confirm-password'];


if ($password !== $confirm_password) {
    die("Passwords do not match.");
}


$hashed_password = password_hash($password, PASSWORD_BCRYPT);


$sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $firstname, $email, $hashed_password);

if ($stmt->execute()) {
    header("Location: p.login.html"); // Redirect to login page after successful registration (try again mine doesn't want to redirect)
    exit;
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>


